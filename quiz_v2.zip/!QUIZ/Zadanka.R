# Zadanie 1 
# Prawdopodobie�stwa przedzia�u w rozk�adzie Poissona
ppois(30,20)-ppois(19,20)
ppois(30,30)-ppois(24,30)

# Zadanie 2
# Ilo�� dla jakiej rozk�ady Poissona i dwumianowy r�ni� si� najbardziej
print("W arkuszu")

# Zadanie 3
# Regresja liniowa ile wyniesie y dla podanego x
czas<-c(5,6,10,7,15,4,10,20,25,8)
punkty<-c(30,30,49,30,65,20,51,85,100,40)
lm(punkty~czas)
16*3.756+8.686 

# Zadanie 4
# Prawdopodobie�stwo, �e suma sumy rozk�ad�w wyk�adniczych wyniesie co najmniej podane X ile�
print("W arkuszu")
pnorm(0.4193139347)

# poni�ej podanego X
X<-20*60
ex1<-3
ex2<-6
sd1<-3
sd2<-6
n<-28*5
exs1<-ex1*n
exs2<-ex2*n
sds1<-sd1*sqrt(n)
sds2<-sd2*sqrt(n)
EX<-exs1+exs2
SD<-sqrt(sds1^2+sds2^2)
print(S<-(X-EX)/SD)
pnorm(S)

# Zadanie 5
# Prawdopodobie�stwo przedzia�u w rozk�adzie wyk�adniczym o podanej �redniej
pexp(130,1/100)-pexp(80,1/100)
round(pexp(130,1/100)-pexp(80,1/100),4)

# Zadanie 6
# Najwy�sze prawdopodobie�stwo, �e dwie cechy s� niezale�ne
print(macierz<-matrix(c(101,22,80,47,25,35), ncol = 2))
chisq.test(macierz)
1-0.01358

macierz<-matrix(c(10,20,60,5,15,25), ncol=2)
chisq.test(macierz)
1-0.3648

# Zadanie 7
# Warto�� jakiej nie przekracza cecha o rozk�adzie normalnym z podanym prawdopodobie�stwem i pr�b�
w<-c(140,110,121,128,132)
alfa<-0.01
sd<-sd(w)
n<-5
print(sqrt((n-1)*sd^2/qchisq(alfa,n-1)))

w<-c(110,121,128,124,132)
alfa<-0.01
sd<-sd(w)
n<-5
print(sqrt((n-1)*sd^2/qchisq(1-alfa,n-1)))

#

a_vec<-seq(30,40,by=.00001)
my_fun<-function(x,a){
  if(x<40){dpois(x,a)}
  else {1-ppois(39.5,a)}
}

wiar_a<-sapply(a_vec,function(a){
  log(my_fun(30,a))+
    log(my_fun(40,a))+
    log(my_fun(40,a))+
    log(my_fun(30,a))+
    log(my_fun(35,a))+
    log(my_fun(40,a))+
    log(my_fun(40,a))
  
})
a_vec[wiar_a==max(wiar_a)]