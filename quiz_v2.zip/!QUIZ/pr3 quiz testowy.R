#zad1
p<-c(.2,.4,.3,.1)
w<-c(0:3)

EX <- sum(p*w)
varx <- sum(p* w ^2) - EX ^2
sqrt(varx)
#zad 2 na kartce
#zad 3
a_vec <- seq(0.1,2 / .74,by=.0001)

my_fun <- function(x,a){
  a-a^2*x/2
}

wiar_a <- sapply(a_vec,function(a){
  log(my_fun(.02,a))+
  log(my_fun(.69,a))+
  log(my_fun(.14,a))+
  log(my_fun(.08,a))+
  log(my_fun(.36,a))+
  log(my_fun(.74,a))
})
plot(a_vec,wiar_a)
a_vec[wiar_a==max(wiar_a, na.rm = T)]
#???????????????????????????
#zad4
#?rexp
szes<-c(1,1,2,2,2,2)

#zad5
p<-rep(c(1/9,2/9),3)
w<-1:6

EX <- sum(p*w)
varx <-sum(p*w^2)-EX ^2
SX <- sqrt(varx)

round(pnorm(3.5,EX,SX/10),4) #pnorm to dystrybuanta

#zad6
#typowe zadanie na przedzial ufnosci

#zad7
#robilismy w zeszlym tygodniu podobne ?

#zad8 
#zadanie na 2 min jak ktoś rozumie co to sa testy, recznie albo kalkulator albo tablice
#qnorm(.995) kwantyl - odwrotnie od pnrom

#zad9
#?pchisq
#mozna z tablic, mozna zrobic wektor

w_kryt <- pchisq(.95,1) #jeden stopnien swobody bo dwie grupy

chisq.test(c(6,14))

round(1-pbinom(14.5,size=20,prob=.60),4)
#zad10 
#podstawienie do wzoru








